function getId(id) {
    return document.getElementById(id)
}
function append(parent,el) {
    return parent.appendChild(el);
}
function createNode(element){
    return document.createElement(element);
}
function myFunction() {
    var input, filter, table, tr, td, i;
    getId("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementById("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }
var tbody = getId('tbody')
fetch('https://swapi.co/api/people')
    .then((d) => d.json())
    .then((people) => {
      console.log(people)
        const { results } = people
        for (var i = 0; i < results.length; i++) {
            const { name,height,mass } = results[i]
            var tr = createNode('tr')
            tr.setAttribute('id',i)
            tbody.appendChild(tr)
            for(var y = 0; y < 2; y++) {
                var abc = getId(i)
                const key = [name,height]
                var td = createNode('td')
                var textnode = document.createTextNode(key[y]);
                td.appendChild(textnode);
                abc.appendChild(td)
            }
        }

    }
    )